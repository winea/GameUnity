This asset pack was made possible by Michael Cook and PROCJAM Community of developers.  PROCJAM is an annual event about "making things that make things". The community make games, art, toys, tools and other things with generative code. 
This year's main event takes place: Nov 4th - Nov. 13th 2017.  
PROCJAM  also have talks you can watch, art you can download, a zine you can read, and a really friendly community. 
This asset pack also features additional art by the talented -  Dan Huynh

This Low-Poly-Pixel-Styled-RPG Game Asset Pack contains over 100+ 3D models. The pack come with a wide variety of optimized assets which has been textured, unwrapped, and UV mapped. The mesh and texture are very small and can be used in RPG Dungeon, Game Worlds, Multiplayer and more. This pack also contains over 400+ 2D rendered assets (8 Directions) in isometric and side, and top view, and bonus Sprites, and JPGA assets! 

You also get a Unity Package File, making it easier to jump directly into game development.

3D Model Specifications
Geometry: Polygon
Formats - *.FBX, and Unity Package File
Textures: Yes
Materials: Yes
UV Mapped: Yes
Unwrapped UVs: Yes
Texture Format: PNG, TGA,
Texture Size: 64x64
Maps: Diffuse (Color)
Mobile Ready: Yes
Tried and Tested in: Unity 5+, 2017+


2D Specifications
Texture Format: PNG, TGA,
Views - rendered in 8 directions 
Views - Isometric, Top, Side
Texture Size: ~ vary
Also contains JPGA for game development



Features
Free periodic updates
Only available at itch.io store and Procjam.com
Professionally organized textures
Very clean models/mesh
Mobile safe for Unity projects
Please leave a review, If you like these assets or have a specific art asset need.



License 

Attribution-NonCommercial 3.0 Unported (CC BY-NC 3.0)

You are free to:

Share � copy and redistribute the material in any medium or format
Adapt � remix, transform, and build upon the material

Under the following terms:

Attribution � You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.


NonCommercial � You may not use the material for commercial purposes.


More info on this license - https://creativecommons.org/licenses/by-nc/3.0/legalcode




When in doubt, the simplest thing to do is to email help@devilsgarage.com

Art - Ajay Karat (twitter.com/devilsgarage)
Additional Art - Dan Huynh (dribbble.com/danny-huynh)

devilsgarage.itch.io
www.devilsgarage.com

