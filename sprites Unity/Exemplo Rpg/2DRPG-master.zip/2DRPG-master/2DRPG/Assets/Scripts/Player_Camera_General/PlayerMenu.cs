﻿using UnityEngine;
using System.Collections;

public class PlayerMenu : MonoBehaviour
{
    void Start()
    {
    
    }
    
    void Update()
    {
       
    }
}
