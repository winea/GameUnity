﻿using UnityEngine;
using UnityEditor;

public class Item : MonoBehaviour
{
    public PickableItemProperties item;

    
}