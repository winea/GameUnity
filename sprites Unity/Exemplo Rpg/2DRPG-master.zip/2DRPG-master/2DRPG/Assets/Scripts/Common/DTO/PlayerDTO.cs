using UnityEngine;
using System.Collections;

public class PlayerDTO
{
    public int HP { get; set; }
    public string Level { get; set; }

}

